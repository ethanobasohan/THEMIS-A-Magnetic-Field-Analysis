from cdflib import CDF
import numpy as np
import os

# --------------------------------------------------
# WEEK 2 THEMIS-A ANALYSIS
# July 1 - December 31, 2014
# --------------------------------------------------

# Find all FGM files
files = os.listdir(".")
fgm_files = sorted(
    f for f in files
    if f.endswith(".cdf") and "tha_l2_fgm_2014" in f
)

print("FGM files found:", len(fgm_files))

# Storage
all_time = []
all_bx = []
all_by = []
all_bz = []

# Read every FGM file
for filename in fgm_files:

    # Ignore empty files
    if os.path.getsize(filename) == 0:
        print("Skipping empty file:", filename)
        continue

    print("Reading:", filename)

    try:
        cdf = CDF(filename)

        time_data = np.asarray(
            cdf.varget("tha_fgs_time")
        ).reshape(-1)

        field_data = np.asarray(
            cdf.varget("tha_fgs_gsm")
        )

        all_time.append(time_data)
        all_bx.append(field_data[:, 0])
        all_by.append(field_data[:, 1])
        all_bz.append(field_data[:, 2])

    except Exception as error:
        print("Skipping unreadable file:", filename)
        print("Reason:", error)


# Combine all days
all_time = np.concatenate(all_time)
all_bx = np.concatenate(all_bx)
all_by = np.concatenate(all_by)
all_bz = np.concatenate(all_bz)


# Create M
# Column 0 = Time
# Column 1 = Bx
# Column 2 = By
# Column 3 = Bz

M = np.column_stack((
    all_time,
    all_bx,
    all_by,
    all_bz
))


# Display results
print()
print("FGM PROCESSING COMPLETE")
print("Rows in M:", M.shape[0])
print("Columns in M:", M.shape[1])

print()
print("First 5 rows of M:")
print(M[:5])

# --------------------------------------------------
# STEP 2: LOAD STATE POSITION DATA
# --------------------------------------------------

state_files = sorted(
    f for f in files
    if f.endswith(".cdf") and "tha_l1_state_2014" in f
)

print()
print("STATE files found:", len(state_files))

state_time = []
state_x = []
state_y = []
state_z = []

for filename in state_files:

    print("Reading STATE:", filename)

    try:
        cdf = CDF(filename)

        time_data = np.asarray(
            cdf.varget("tha_state_time")
        ).reshape(-1)

        position_data = np.asarray(
            cdf.varget("tha_pos_gsm")
        )

        state_time.append(time_data)
        state_x.append(position_data[:, 0])
        state_y.append(position_data[:, 1])
        state_z.append(position_data[:, 2])

    except Exception as error:
        print("Could not read:", filename)
        print("Reason:", error)


# Combine all STATE days

state_time = np.concatenate(state_time)
state_x = np.concatenate(state_x)
state_y = np.concatenate(state_y)
state_z = np.concatenate(state_z)

print()
print("STATE processing complete.")
print("STATE measurements:", len(state_time))


# --------------------------------------------------
# INTERPOLATE POSITION TO FGM TIMESTAMPS
# --------------------------------------------------

print()
print("Interpolating spacecraft position...")

X = np.interp(all_time, state_time, state_x)
Y = np.interp(all_time, state_time, state_y)
Z = np.interp(all_time, state_time, state_z)


# Add X, Y, Z to M

M = np.column_stack((
    all_time,
    all_bx,
    all_by,
    all_bz,
    X,
    Y,
    Z
))

print()
print("POSITION INTERPOLATION COMPLETE")
print("Rows in M:", M.shape[0])
print("Columns in M:", M.shape[1])

print()
print("Column structure:")
print("0 = Time")
print("1 = Bx")
print("2 = By")
print("3 = Bz")
print("4 = X")
print("5 = Y")
print("6 = Z")

print()
print("First 5 rows:")
print(M[:5])

# --------------------------------------------------
# STEP 3: APPLY RESTRICTIONS
# --------------------------------------------------

RE = 6300.0

# Individual restrictions
restriction_1 = X < (-6 * RE)
restriction_2 = np.abs(Y) < (np.abs(X) / 2)
restriction_3 = np.sqrt(all_bx**2 + all_by**2) < 15

# All three conditions must be true
restricted_mask = (
    restriction_1
    & restriction_2
    & restriction_3
)

# Create restricted matrix
M_restricted = M[restricted_mask]

print()
print("RESTRICTION PROCESSING COMPLETE")

print("Full data rows:", M.shape[0])
print("Restricted data rows:", M_restricted.shape[0])

print()
print("Restrictions used:")
print("X < -37800 km")
print("|Y| < |X| / 2")
print("sqrt(Bx^2 + By^2) < 15 nT")

print()
print("First 5 restricted rows:")
print(M_restricted[:5])

# --------------------------------------------------
# STEP 4: Bz STATISTICS AND HISTOGRAMS
# --------------------------------------------------

import matplotlib.pyplot as plt

# Bz is column 3 of M
bz_full = M[:, 3]
bz_restricted = M_restricted[:, 3]

# Remove any non-finite values
bz_full = bz_full[np.isfinite(bz_full)]
bz_restricted = bz_restricted[np.isfinite(bz_restricted)]


def print_statistics(name, data):
    print()
    print(name)
    print("Number of measurements:", len(data))
    print("Mean Bz:", np.mean(data), "nT")
    print("Median Bz:", np.median(data), "nT")
    print("Standard deviation:", np.std(data), "nT")
    print("Minimum Bz:", np.min(data), "nT")
    print("Maximum Bz:", np.max(data), "nT")


# Statistics
print_statistics("FULL SET Bz STATISTICS", bz_full)
print_statistics("RESTRICTED SET Bz STATISTICS", bz_restricted)


# --------------------------------------------------
# HISTOGRAMS
# Try different bin sizes: 50, 100, and 200
# --------------------------------------------------

for bins in [50, 100, 200]:

    # Full set - linear scale
    plt.figure(figsize=(9, 6))
    plt.hist(bz_full, bins=bins)
    plt.xlabel("Bz (nT)")
    plt.ylabel("Number of Measurements")
    plt.title(f"Full Set Bz Histogram - {bins} Bins")
    plt.tight_layout()
    plt.savefig(f"bz_full_{bins}_bins_linear.png")
    plt.close()

        # Full set Bz - logarithmic histogram without extreme values
    bz_filtered = bz_full[(bz_full >= -100) & (bz_full <= 150)]

    plt.figure(figsize=(9, 6))
    plt.hist(bz_filtered, bins=bins)
    plt.yscale("log")
    plt.xlabel("Bz (nT)")
    plt.ylabel("Number of Measurements (Log Scale)")
    plt.title(f"Full Set Bz Histogram - Filtered - {bins} Bins")
    plt.tight_layout()
    plt.savefig(f"bz_full_filtered_{bins}_bins_log.png", dpi=200)
    plt.close()

    

    # Full set - logarithmic scale
    plt.figure(figsize=(9, 6))
    plt.hist(bz_full, bins=bins)
    plt.yscale("log")
    plt.xlabel("Bz (nT)")
    plt.ylabel("Number of Measurements (Log Scale)")
    plt.title(f"Full Set Bz Histogram - {bins} Bins - Log Scale")
    plt.tight_layout()
    plt.savefig(f"bz_full_{bins}_bins_log.png")
    plt.close()

    # Restricted set - linear scale
    plt.figure(figsize=(9, 6))
    plt.hist(bz_restricted, bins=bins)
    plt.xlabel("Bz (nT)")
    plt.ylabel("Number of Measurements")
    plt.title(f"Restricted Set Bz Histogram - {bins} Bins")
    plt.tight_layout()
    plt.savefig(f"bz_restricted_{bins}_bins_linear.png")
    plt.close()

    # Restricted set - logarithmic scale
    plt.figure(figsize=(9, 6))
    plt.hist(bz_restricted, bins=bins)
    plt.yscale("log")
    plt.xlabel("Bz (nT)")
    plt.ylabel("Number of Measurements (Log Scale)")
    plt.title(f"Restricted Set Bz Histogram - {bins} Bins - Log Scale")
    plt.tight_layout()
    plt.savefig(f"bz_restricted_{bins}_bins_log.png")
    plt.close()

    # Full set - zoomed logarithmic histogram
plt.figure(figsize=(9, 6))

plt.hist(bz_full, bins=bins, range=(-100, 150))

plt.yscale("log")
plt.xlabel("Bz (nT)")
plt.ylabel("Number of Measurements (Log Scale)")
plt.title(f"Full Set Bz Histogram - Zoomed - {bins} Bins")

plt.tight_layout()
plt.savefig(f"bz_full_zoomed_{bins}_bins_log.png", dpi=200)
plt.close()


print()
print("Bz HISTOGRAMS COMPLETE")
print("Histogram images saved in the current folder.")

# --------------------------------------------------
# STEP 5: CALCULATE dBz6sec
# --------------------------------------------------

# Create empty dBz6sec array
dBz6sec = np.full(len(M), np.nan)

# Supervisor's formula:
# dBz6sec(i) = Bz(i+1) - Bz(i-1)
dBz6sec[1:-1] = M[2:, 3] - M[:-2, 3]

# Check the actual time span between i-1 and i+1.
# If there is a large data gap, do not treat it as a 6-second change.
time_span = M[2:, 0] - M[:-2, 0]
valid_6sec = (time_span >= 4) & (time_span <= 8)

middle_values = dBz6sec[1:-1]
middle_values[~valid_6sec] = np.nan
dBz6sec[1:-1] = middle_values

# Add dBz6sec as column 8
M = np.column_stack((M, dBz6sec))

print()
print("dBz6sec CALCULATION COMPLETE")
print("Rows in M:", M.shape[0])
print("Columns in M:", M.shape[1])
print("Valid dBz6sec measurements:", np.sum(np.isfinite(dBz6sec)))

print()
print("Column structure:")
print("0 = Time")
print("1 = Bx")
print("2 = By")
print("3 = Bz")
print("4 = X")
print("5 = Y")
print("6 = Z")
print("7 = dBz6sec")

# --------------------------------------------------
# STEP 6: ANALYZE dBz6sec
# --------------------------------------------------

# Valid full-set dBz6sec values
dbz_full = dBz6sec[np.isfinite(dBz6sec)]

# Restricted-set dBz6sec values
dbz_restricted = dBz6sec[restricted_mask]
dbz_restricted = dbz_restricted[np.isfinite(dbz_restricted)]

print()
print("FULL SET dBz6sec STATISTICS")
print("Number of measurements:", len(dbz_full))
print("Mean:", np.mean(dbz_full), "nT")
print("Median:", np.median(dbz_full), "nT")
print("Standard deviation:", np.std(dbz_full), "nT")
print("Minimum:", np.min(dbz_full), "nT")
print("Maximum:", np.max(dbz_full), "nT")

print()
print("RESTRICTED SET dBz6sec STATISTICS")
print("Number of measurements:", len(dbz_restricted))
print("Mean:", np.mean(dbz_restricted), "nT")
print("Median:", np.median(dbz_restricted), "nT")
print("Standard deviation:", np.std(dbz_restricted), "nT")
print("Minimum:", np.min(dbz_restricted), "nT")
print("Maximum:", np.max(dbz_restricted), "nT")


# --------------------------------------------------
# dBz6sec vs time
# --------------------------------------------------

# Downsample for plotting only.
# Statistics above still use every valid measurement.
plot_step = 30

valid_plot = np.isfinite(dBz6sec[::plot_step])

plt.figure(figsize=(40, 20))
plt.plot(
    all_time[::plot_step][valid_plot],
    dBz6sec[::plot_step][valid_plot],
    linewidth=0.5
)

plt.xlabel("Time")
plt.ylabel("dBz6sec (nT)")
plt.title("THEMIS-A dBz6sec vs Time: July-December 2014")
plt.tight_layout()
plt.savefig("dBz6sec_vs_updated_time.png", dpi=200)
plt.close()


# --------------------------------------------------
# dBz6sec HISTOGRAMS
# --------------------------------------------------

for bins in [50, 100, 200]:

    # Full set - linear
    plt.figure(figsize=(8, 5))
    plt.hist(dbz_full, bins=bins)
    plt.xlabel("dBz6sec (nT)")
    plt.ylabel("Count")
    plt.title(f"Full Set dBz6sec Histogram ({bins} bins)")
    plt.tight_layout()
    plt.savefig(f"dBz_full_linear_{bins}bins.png", dpi=200)
    plt.close()

        # Full set - zoomed linear histogram
    plt.figure(figsize=(9, 6))

    plt.hist(bz_full, bins=bins, range=(-100, 150))

    plt.xlabel("Bz (nT)")
    plt.ylabel("Number of Measurements")
    plt.title(f"Full Set Bz Histogram - Zoomed - {bins} Bins")

    plt.tight_layout()
    plt.savefig(f"bz_full_zoomed_{bins}_bins_linear.png", dpi=200)
    plt.close()

        # Full set dBz6sec - zoomed linear histogram
    plt.figure(figsize=(8, 5))

    plt.hist(dbz_full, bins=bins, range=(-5, 5))

    plt.xlabel("dBz6sec (nT)")
    plt.ylabel("Number of Measurements")
    plt.title(f"Full Set dBz6sec Histogram - Zoomed ({bins} bins)")

    plt.tight_layout()
    plt.savefig(f"dBz_full_zoomed_linear_{bins}bins.png", dpi=200)
    plt.close()

    # Full set - logarithmic count
    plt.figure(figsize=(8, 5))
    plt.hist(dbz_full, bins=bins)
    plt.yscale("log")
    plt.xlabel("dBz6sec (nT)")
    plt.ylabel("Count (log scale)")
    plt.title(f"Full Set dBz6sec Histogram - Log Scale ({bins} bins)")
    plt.tight_layout()
    plt.savefig(f"dBz_full_log_{bins}bins.png", dpi=200)
    plt.close()

    # Restricted set - linear
    plt.figure(figsize=(8, 5))
    plt.hist(dbz_restricted, bins=bins)
    plt.xlabel("dBz6sec (nT)")
    plt.ylabel("Count")
    plt.title(f"Restricted Set dBz6sec Histogram ({bins} bins)")
    plt.tight_layout()
    plt.savefig(f"dBz_restricted_linear_{bins}bins.png", dpi=200)
    plt.close()

    # Restricted set - logarithmic count
    plt.figure(figsize=(8, 5))
    plt.hist(dbz_restricted, bins=bins)
    plt.yscale("log")
    plt.xlabel("dBz6sec (nT)")
    plt.ylabel("Count (log scale)")
    plt.title(
        f"Restricted Set dBz6sec Histogram - Log Scale ({bins} bins)"
    )
    plt.tight_layout()
    plt.savefig(f"dBz_restricted_log_{bins}bins.png", dpi=200)
    plt.close()

print()
print("dBz6sec ANALYSIS COMPLETE")
print("Plot and histogram images saved in the current folder.")